//5 Card Draw CPSC1045 Project
//Bruce Yi Chen Zhao
//100298997

let ds = document.getElementById("myCanvas");
let ctx = ds.getContext("2d");
ctx.font = "20px Ariel"

//Loads the card arts. https://code.google.com/archive/p/vector-playing-cards/downloads
let cards = [];

function createImage(str)
{
	let temp = new Image()
	temp.src = str;
	return temp;
}

cards.push(createImage("ace_of_spades.png"));
cards.push(createImage("2_of_spades.png"));
cards.push(createImage("3_of_spades.png"));
cards.push(createImage("4_of_spades.png"));
cards.push(createImage("5_of_spades.png"));
cards.push(createImage("6_of_spades.png"));
cards.push(createImage("7_of_spades.png"));
cards.push(createImage("8_of_spades.png"));
cards.push(createImage("9_of_spades.png"));
cards.push(createImage("10_of_spades.png"));
cards.push(createImage("jack_of_spades2.png"));
cards.push(createImage("queen_of_spades2.png"));
cards.push(createImage("King_of_spades2.png"));
cards.push(createImage("ace_of_hearts.png"));
cards.push(createImage("2_of_hearts.png"));
cards.push(createImage("3_of_hearts.png"));
cards.push(createImage("4_of_hearts.png"));
cards.push(createImage("5_of_hearts.png"));
cards.push(createImage("6_of_hearts.png"));
cards.push(createImage("7_of_hearts.png"));
cards.push(createImage("8_of_hearts.png"));
cards.push(createImage("9_of_hearts.png"));
cards.push(createImage("10_of_hearts.png"));
cards.push(createImage("jack_of_hearts2.png"));
cards.push(createImage("queen_of_hearts2.png"));
cards.push(createImage("King_of_hearts2.png"));
cards.push(createImage("ace_of_clubs.png"));
cards.push(createImage("2_of_clubs.png"));
cards.push(createImage("3_of_clubs.png"));
cards.push(createImage("4_of_clubs.png"));
cards.push(createImage("5_of_clubs.png"));
cards.push(createImage("6_of_clubs.png"));
cards.push(createImage("7_of_clubs.png"));
cards.push(createImage("8_of_clubs.png"));
cards.push(createImage("9_of_clubs.png"));
cards.push(createImage("10_of_clubs.png"));
cards.push(createImage("jack_of_clubs2.png"));
cards.push(createImage("queen_of_clubs2.png"));
cards.push(createImage("King_of_clubs2.png"));
cards.push(createImage("ace_of_diamonds.png"));
cards.push(createImage("2_of_diamonds.png"));
cards.push(createImage("3_of_diamonds.png"));
cards.push(createImage("4_of_diamonds.png"));
cards.push(createImage("5_of_diamonds.png"));
cards.push(createImage("6_of_diamonds.png"));
cards.push(createImage("7_of_diamonds.png"));
cards.push(createImage("8_of_diamonds.png"));
cards.push(createImage("9_of_diamonds.png"));
cards.push(createImage("10_of_diamonds.png"));
cards.push(createImage("jack_of_diamonds2.png"));
cards.push(createImage("queen_of_diamonds2.png"));
cards.push(createImage("King_of_diamonds2.png"));

//Loads the welcome screen.
window.onload = function() {
	ctx.fillText("Video Poker: 5 cards draw", 190, 160);
	ctx.fillText("Author: Bruce Zhao", 220, 190);
	ctx.fillText("Click start/reset to start the game", 170, 220);
};

//global variables
let currentHand = [];
let button1 = false;
let button2 = false;
let button3 = false;
let button4 = false;
let button5 = false;

//Onclick of the reset/start button.
function resetCards()
{
	let i     = 0;
	let j     = 0;
	let hands = [];	
	let temp;
	let noDuplicate = true;
	
	//Resets the selections.
	button1 = false;
	button2 = false;
	button3 = false;
	button4 = false;
	button5 = false;
	
	//Assign 10 unique numbers between 0 and 51 into an array.
	for (i = 0; i < 10; i++)
	{		
		do
		{
			noDuplicate = true;	
			temp = Math.floor(Math.random() * 52);
			for (j = 0; j < hands.length; j++)
			{
				if (temp == hands[j])
				{
					noDuplicate = false;
				}	
			}	
		} while (!noDuplicate)
			
		hands.push(temp);		
	}	
	/**
	console.log("" + hands[0] + " " + hands[1] + " " + hands[2] + " " + hands[3] + " " + hands[4] + " " + 
					hands[5] + " " + hands[6] + " " + hands[7] + " " + hands[8] + " " + hands[9]);
	*/
	//Sets the global variable currentHand and returns the array.
	currentHand	= hands;
	return hands;				
}

//Draws the canvas with the correct cards.
function redrawCanvas(arr)
{
	ctx.clearRect(0, 0, 600, 420);
	ctx.fillText("Computer's cards", 10, 20);
    ctx.drawImage(cards[arr[0]], 20, 40, 100, 150);
	ctx.strokeRect(20, 40, 100, 150);
	ctx.drawImage(cards[arr[1]], 130, 40, 100, 150);
	ctx.strokeRect(130, 40, 100, 150);
	ctx.drawImage(cards[arr[2]], 240, 40, 100, 150);
	ctx.strokeRect(240, 40, 100, 150);
	ctx.drawImage(cards[arr[3]], 350, 40, 100, 150);
	ctx.strokeRect(350, 40, 100, 150);
	ctx.drawImage(cards[arr[4]], 460, 40, 100, 150);
	ctx.strokeRect(460, 40, 100, 150);
	
	ctx.fillText("Player's cards", 10, 225);
	ctx.drawImage(cards[arr[5]], 20, 245, 100, 150);
	ctx.strokeRect(20, 245, 100, 150);
	ctx.drawImage(cards[arr[6]], 130, 245, 100, 150);
	ctx.strokeRect(130, 245, 100, 150);
	ctx.drawImage(cards[arr[7]], 240, 245, 100, 150);
	ctx.strokeRect(240, 245, 100, 150);
	ctx.drawImage(cards[arr[8]], 350, 245, 100, 150);
	ctx.strokeRect(350, 245, 100, 150);
	ctx.drawImage(cards[arr[9]], 460, 245, 100, 150);
	ctx.strokeRect(460, 245, 100, 150);	
}

//Onclick for the select buttons.
function card(id)
{
	switch(id)
	{
		case "b1":  if (button1 == false)
					{
						console.log("Card 1 is selected.");
						button1 = true;
					}
					else if (button1 == true)
					{
						console.log("Card 1 is unselected.");
						button1 = false;
					}
					break;
					
		case "b2":	if (button2 == false)
					{
						console.log("Card 2 is selected.");
						button2 = true;
					}
					else if (button2 == true)
					{
						console.log("Card 2 is unselected.");
						button2 = false;
					}
					break;
					
		case "b3":	if (button3 == false)
					{
						console.log("Card 3 is selected.");
						button3 = true;
					}
					else if (button3 == true)
					{
						console.log("Card 3 is unselected.");
						button3 = false;
					}
					break;
					
		case "b4":	if (button4 == false)
					{
						console.log("Card 4 is selected.");
						button4 = true;
					}
					else if (button4 == true)
					{
						console.log("Card 4 is unselected.");
						button4 = false;
					}
					break;
					
		case "b5":	if (button5 == false)
					{
						console.log("Card 5 is selected.");
						button5 = true;
					}
					else if (button5 == true)
					{
						console.log("Card 5 is unselected.");
						button5 = false;
					}
					break;
	}
}

//Onclick for the button redraw.
function redrawCards()
{
	let noDuplicate = true;
	let i     = 0;
	let temp;
	let discard = [];
	
	if (button1 == true)
	{	
		do
		{
			noDuplicate = true;	
			temp = Math.floor(Math.random() * 52);
			for (i = 0; i < currentHand.length; i++)
			{
				if (temp == currentHand[i])
				{
					noDuplicate = false;
				}	
			}
			
			for (i = 0; i < discard.length; i++)
			{
				if (temp == discard[i])
				{
					noDuplicate = false;
				}	
			}	
		} while (!noDuplicate)
		
		discard.push(currentHand[5]);
		currentHand[5] = temp;	
	}	

	if (button2 == true)
	{	
		do
		{
			noDuplicate = true;	
			temp = Math.floor(Math.random() * 52);
			for (i = 0; i < currentHand.length; i++)
			{
				if (temp == currentHand[i])
				{
					noDuplicate = false;
				}	
			}
				
			for (i = 0; i < discard.length; i++)
			{
				if (temp == discard[i])
				{
					noDuplicate = false;
				}	
			}	
		} while (!noDuplicate)
		
		discard.push(currentHand[6]);
		currentHand[6] = temp;	
	}

	if (button3 == true)
	{	
		do
		{
			noDuplicate = true;	
			temp = Math.floor(Math.random() * 52);
			for (i = 0; i < currentHand.length; i++)
			{
				if (temp == currentHand[i])
				{
					noDuplicate = false;
				}
			}
			
			for (i = 0; i < discard.length; i++)
			{
				if (temp == discard[i])
				{
					noDuplicate = false;
				}	
			}		
		} while (!noDuplicate)
		
		discard.push(currentHand[7]);	
		currentHand[7] = temp;	
	}

	if (button4 == true)
	{	
		do
		{
			noDuplicate = true;	
			temp = Math.floor(Math.random() * 52);
			for (i = 0; i < currentHand.length; i++)
			{
				if (temp == currentHand[i])
				{
					noDuplicate = false;
				}	
			}

			for (i = 0; i < discard.length; i++)
			{
				if (temp == discard[i])
				{
					noDuplicate = false;
				}	
			}			
		} while (!noDuplicate)
		
		discard.push(currentHand[8]);
		currentHand[8] = temp;	
	}

	if (button5 == true)
	{	
		do
		{
			noDuplicate = true;	
			temp = Math.floor(Math.random() * 52);
			for (i = 0; i < currentHand.length; i++)
			{
				if (temp == currentHand[i])
				{
					noDuplicate = false;
				}	
			}

			for (i = 0; i < discard.length; i++)
			{
				if (temp == discard[i])
				{
					noDuplicate = false;
				}	
			}	
		} while (!noDuplicate)
		
		discard.push(currentHand[9]);	
		currentHand[9] = temp;	
	}
	
	redrawCanvas(currentHand);
}
